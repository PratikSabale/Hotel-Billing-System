import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
    private static final String URL = "jdbc:sqlite:hotel.db";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void initializeDatabase() {
        try (Connection conn = connect();
             PreparedStatement createUserTable = conn.prepareStatement(
                     "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL)");
             PreparedStatement createItemTable = conn.prepareStatement(
                     "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL)");
             PreparedStatement createBillTable = conn.prepareStatement(
                     "CREATE TABLE IF NOT EXISTS bills (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id))");
             PreparedStatement createBillItemTable = conn.prepareStatement(
                     "CREATE TABLE IF NOT EXISTS bill_items (id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id INTEGER NOT NULL, item_id INTEGER NOT NULL, FOREIGN KEY (bill_id) REFERENCES bills(id), FOREIGN KEY (item_id) REFERENCES items(id))")) {

            createUserTable.execute();
            createItemTable.execute();
            createBillTable.execute();
            createBillItemTable.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
