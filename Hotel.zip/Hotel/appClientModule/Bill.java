import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.ResultSet;

public class Bill {
    private List<Item> items;
    private double taxRate;
    private double discount;
    private int userId;

    public Bill(double taxRate, double discount, int userId) {
        this.items = new ArrayList<>();
        this.taxRate = taxRate;
        this.discount = discount;
        this.userId = userId;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public double calculateSubtotal() {
        double subtotal = 0.0;
        for (Item item : items) {
            subtotal += item.getPrice();
        }
        return subtotal;
    }

    public double calculateTax() {
        return calculateSubtotal() * taxRate;
    }

    public double calculateDiscount() {
        return calculateSubtotal() * discount;
    }

    public double calculateTotal() {
        return calculateSubtotal() + calculateTax() - calculateDiscount();
    }

    public void displayBill() {
        System.out.println("----- Bill -----");
        for (Item item : items) {
            System.out.println(item);
        }
        System.out.println("Subtotal: $" + calculateSubtotal());
        System.out.println("Tax: $" + calculateTax());
        System.out.println("Discount: $" + calculateDiscount());
        System.out.println("Total: $" + calculateTotal());
    }

    public void saveBill() {
        String billSql = "INSERT INTO bills(user_id) VALUES(?)";
        String billItemSql = "INSERT INTO bill_items(bill_id, item_id) VALUES(?, ?)";

        try (Connection conn = Database.connect();
             PreparedStatement billPstmt = conn.prepareStatement(billSql, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement billItemPstmt = conn.prepareStatement(billItemSql)) {

            billPstmt.setInt(1, userId);
            billPstmt.executeUpdate();
            java.sql.ResultSet generatedKeys = billPstmt.getGeneratedKeys();
            int billId = 0;
            if (generatedKeys.next()) {
                billId = generatedKeys.getInt(1);
            }

            for (Item item : items) {
                billItemPstmt.setInt(1, billId);
                billItemPstmt.setInt(2, item.getId()); // Assuming Item class has getId method
                billItemPstmt.executeUpdate();
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
