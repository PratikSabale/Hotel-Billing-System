import java.util.Scanner;

public class HotelBillingSystem {
    private static UserManager userManager = new UserManager();
    private static Scanner scanner = new Scanner(System.in);
    private static Bill bill;
    private static User currentUser;

    public static void main(String[] args) {
        Database.initializeDatabase();

        while (true) {
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void register() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (userManager.registerUser(username, password)) {
            System.out.println("User registered successfully.");
        } else {
            System.out.println("Username already taken.");
        }
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        currentUser = userManager.loginUser(username, password);
        if (currentUser != null) {
            System.out.println("Login successful.");
            handleBilling();
        } else {
            System.out.println("Invalid username or password.");
        }
    }

    private static void handleBilling() {
        bill = new Bill(0.08, 0.1, getUserId(currentUser.getUsername())); // Example tax rate of 8% and discount of 10%

        while (true) {
        	 System.out.println("1. Add item to bill");
             System.out.println("2. Display bill");
             System.out.println("3. Logout");
             System.out.print("Choose an option: ");
             int choice = scanner.nextInt();
             scanner.nextLine(); // Consume newline

             switch (choice) {
                 case 1:
                     System.out.print("Enter item name: ");
                     String itemName = scanner.nextLine();
                     System.out.print("Enter item price: ");
                     double itemPrice = scanner.nextDouble();
                     scanner.nextLine(); // Consume newline
                     bill.addItem(new Item(itemName, itemPrice));
                     System.out.println("Item added to the bill.");
                     break;
                 case 2:
                     bill.displayBill();
                     break;
                 case 3:
                     System.out.println("Logging out...");
                     return;
                 default:
                     System.out.println("Invalid choice, please try again.");
             }
         }
     }

	private static int getUserId(String username) {
		// TODO Auto-generated method stub
		return 0;
	}
 }
        
